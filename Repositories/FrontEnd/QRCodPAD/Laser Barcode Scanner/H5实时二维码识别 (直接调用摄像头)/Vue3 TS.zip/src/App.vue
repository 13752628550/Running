<template>
  <div class="app">
    <router-view></router-view>
  </div>
</template>

<script setup lang="ts"></script>

<style scoped>
.app {
  max-width: 750px;
  font-size: 28px;
}
</style>
