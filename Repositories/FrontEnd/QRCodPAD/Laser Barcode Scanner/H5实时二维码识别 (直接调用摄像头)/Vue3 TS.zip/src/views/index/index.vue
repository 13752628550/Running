<template>
  <div>
    <h1>二维码扫描识别</h1>
    <router-link to="/one">监听一次</router-link>
    <br />
    <br />
    <router-link to="/sastain">持续监听</router-link>
    <br />
    <br />
    <router-link to="/higin">高清识别</router-link>
    <br />
    <br />
  </div>
</template>

<script setup lang="ts"></script>

<style scoped lang="scss">
div {
  font-size: 24px;
}
</style>
