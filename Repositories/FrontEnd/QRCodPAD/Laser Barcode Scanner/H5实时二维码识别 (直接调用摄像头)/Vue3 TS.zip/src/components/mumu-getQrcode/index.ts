/*
 * @Author: 木木
 * @LastEditors: 木木
 * @Date: 2022-06-01 16:03:04
 * @LastEditTime: 2022-06-01 16:04:20
 * @Description:调用摄像头扫描二维码组件
 */
import MumuGetQrcode from './src/mumu-getQrcode.vue'
export default MumuGetQrcode
