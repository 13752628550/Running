module.exports = {
    mysql: {
        host: 'localhost',
        user: 'root',
        password: '123456',
        port: '3306',
        database: 'login'
    }
}
